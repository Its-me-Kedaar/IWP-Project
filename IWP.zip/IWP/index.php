<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="js/main.js" type="text/javascript"></script>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>
     
    </head>
    <body>
        <nav>
            <header style="background: Black;">
                <ul class="left-nav">
                    <li><img src="imgs/a.png" style="width: 50px"></li>
					<li><a href="#" style="text-align:center; font-family: serif ; font-size:2vw;font-weight: bold;">TUTORIAL BLOCK</a></li>
                    
                </ul>
			
                <ul class="right-nav">
                    <li class="dropdown">
                      
                        <div style="margin-bottom: 20px;">
                              <a href="" id="courses">Special-Courses</a>
                        </div>
                        <ul class="sub-menu">
                            <li><a href="#">Interview Preparation</a></li>
                            <li><a href="#">Specialization Courses</a></li>
                            <li><a href="#">Graphics Design</a></li>
                            <li><a href="#">Programming Basics</a></li>
							
                        </ul>
                    </li>
					<li class="dropdown">
                      
                        <div style="margin-bottom: 5px;">
                              <a href="" id="courses">Register</a>
                        </div>
                        <ul class="sub-menu">
                            <li><a href="#">  </a></li>
							<li><a href="login/login.php">Login/sign up</a></li>
                            
                        </ul>
                    </li>
					<li class="dropdown"><a href="portfolio.html">Portfolio</a></li>
                    <li class="chat"><a href="contactus.html" class="minimize-chat">Contact us</a></li>
					
                </ul>
            </header>			
        </nav>
		<hr>
		<main>              
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 10px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}



/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 10px;
  text-align: center;
  background-color: white;
}


</style>

<h2> WEB DEVELOPMENT </h2>

<div class="row">
  <div class="column">
    <div class="card">
	 <img src="imgs/avatar.jpg" alt="Avatar" style="width:200px ; length:absolute ;">
      <h3>Course on HTML</h3>
      <p>
      HTML stands for Hyper Text Markup 
      Language. It is used to design web 
      pages using markup language. HTML 
      is the combination of Hypertext and 
      Markup language. Hypertext defines 
      the link between the web pages.
      </p>
      <form method="get" class="button" action="web/html.html">
    <button type="submit">Start Learning</button>
</form>
    </div>
  </div>

  <div class="column">
    <div class="card">
	<img src="imgs/avatar1.jpg" alt="Avatar" style="width:200px">
      <h3>Course on CSS</h3>
      <p>
                        Cascading Style Sheets, fondly referred 
                        to as CSS, is a simply designed language 
                        intended to simplify the process of 
                        making web pages presentable. CSS allows 
                        you to apply styles to web pages. 
      </p>
      <form method="get" class="button" action="web/css.html">
    <button type="submit">Start Learning</button>
</form>

    </div>
  </div>
  
  <div class="column">
    <div class="card">
	<img src="imgs/avatar2.jpg" alt="Avatar" style="width:210px">
      <h3>Course on Java Script</h3>
      <p>
                        Javascript was developed by Brendan 
                        Eich in 1995. At first, it was called 
                        LiveScript but was later name to 
                        JavaScript. JavaScript is the muscle 
                        of the structure and gives life to the 
                        functionalities by making the web page
                        responsive.
      </p>
      <form method="get" class="button" action="web/javascript.html">
    <button type="submit">Start Learning</button>
</form>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
	 <img src="imgs/avatar3.jpg" alt="Avatar" style="width:200px ; length:absolute ;">
      <h3>Course on PHP</h3>
      <p>
                        The term PHP is an acronym for PHP:  
                        Hypertext Preprocessor. PHP is a  
                        server-side scripting language  
                        designed specifically for web  
                        development. PHP can be easily 
                        embedded in HTML files. 
      </p>
      <form method="get" class="button" action="web/php.html">
    <button type="submit">Start Learning</button>
</form>
    </div>
  </div>
  </div>
  
  <div >
  
  </div >
  
  <div >
  <h2> PROGRAMMING LANGUAGES </h2>

<div class="row">
  <div class="column">
    <div class="card">
	<img src="imgs/cprg.png" alt="Avatar" style="width:175px">
      <h3>Programming in C</h3>
      <p>C programming language is a computer programming 
        language that was developed to do system programming 
        for the operating system UNIX and is an imperative 
        programming language. C was developed in the early 
        1970s by Ken Thompson and Dennis Ritchie at Bell Labs</p>
      <form method="get" class="button" action="prog/c.html">
    <button type="submit">Start Learning</button>
</form>
    </div>
  </div>

  <div class="column">
    <div class="card">
	<img src="imgs/cpprg.jpg" alt="Avatar" style="width:200px">
      <h3>Programming in C++</h3>
      <p>
      C++ is a programming language developed by 
      Bjarne Stroustrup in 1979 at Bell Labs. 
      C++ is a middle-level language, as it comprises 
      a combination of both high-level and low-level language 
      features. It is a superset of C, 
      and that any legal C program is a C++ program
      </p>
      <form method="get" class="button" action="prog/cpp.html">
    <button type="submit">Start Learning</button>
</form>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
	<img src="imgs/pprg.jpg" alt="Avatar" style="width:200px">
      <h3>Programming in PYTHON</h3>
      <p>
      Python is an interpreted, object-oriented, high-level 
      programming language with dynamic semantics. 
      Python is simple to learn 
      readability and therefore reduces the maintenance. 
      Python supports modules and packages, which 
      encourages program modularity and code reuse.
      </p>
      <form method="get" class="button" action="prog/python.html">
    <button type="submit">Start Learning</button>
</form>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
	<img src="imgs/jprg.png" alt="Avatar" style="width:170px">
      <h3>Programming in JAVA</h3>
      <p>
      Java is a high-level programming language developed by Sun Microsystems.
       It was originally designed for developing programs for set-top boxes and 
       handheld devices, but later became a popular choice for creating web applications
       The Java syntax is similar to C++.
      </p>
      <form method="get" class="button" action="prog/java.html">
    <button type="submit">Start Learning</button>
</form>
      
    </div>	
  </div>
 </div>
</div> 

<h2> Data Base Programming </h2>

<div class="row">
  <div class="column">
    <div class="card">
	 <img src="imgs/sql.png" alt="Avatar" style="width:240px ; length:absolute ;">
      <h3>Course on SQL</h3>
      <p>
      SQL is Structured Query Language, which is a computer language 
for storing, manipulating and retrieving data stored in a 
relational database   
    </p>
      <form method="get" class="button" action="database/sql.html">
    <button type="submit">Start Learning</button>
</form>
    </div>
  </div>

  <div class="column">
    <div class="card">
	<img src="imgs/mysql.png" alt="Avatar" style="width:110px">
      <h3>Course on MY SQL</h3>
      <p>
      MySQL is a freely available open source Relational Database 
Management System (RDBMS) that uses Structured Query 
Language (SQL). SQL is the most popular language for 
adding, accessing and managing content in a database.
      </p>
      <form method="get" class="button" action="database/my sql.html">
    <button type="submit">Start Learning</button>
</form>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
	<img src="imgs/mongodb.png" alt="Avatar" style="width:210px">
      <h3>Course on Mongo DB</h3>
      <p>
      MongoDB is a document-oriented NoSQL database used for 
high volume data storage. Instead of using tables like the traditional 
relational database, MongoDB use collection of documents which have
 keyvalue pairs as the basic unit.
      </p>
      <form method="get" class="button" action="database/mongodb.html">
    <button type="submit">Start Learning</button>
</form>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
	 <img src="imgs/swift.png" alt="Avatar" style="width:200px ; length:absolute ;">
      <h3>Course on MS SQL</h3>
      <p>
      The Microsoft relational database system 
is a software product which stores and 
retrieves data requested by other applications. 
These applications run on the same or other computer
 There are many versions of Microsoft SQL Server.
      </p>
      <form method="get" class="button" action="database/mssql.html">
    <button type="submit">Start Learning</button>
</form>
    </div>
  </div>
  </div>
  
  
			</main>
			<hr>
            <footer style=" background: black;">
			<div style="text-align: center; color: white ;">
					&copy  2020 developed by kedaar
			</div>
            <div style="text-align: center; color: white;">
			<p>19BCE1370 </p>
			<p>BANDARU KEDAARNATH </p>
			<p>STUDENT AT VELLORE INSTITUTE OF TECHNOLOGY, CHENNAI CAMPUS</p>
            </div>


		    </footer>
    </body>
</html>