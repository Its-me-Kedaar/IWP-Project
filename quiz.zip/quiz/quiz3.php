<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width, initial-scale=1.0">
    <title>Score Card</title>
    <style>
        table {
            border-collapse: collapse;
            text-align: center;
        }
        td {
            width: 35%;
        }
        h2 {
            color: blue;
        }
        th {
            color: blue;
        }
        body {
            background-color: #808080;
        }
        #ff {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <center>
    <h2>Score Card</h2>
        <table width="70%" border="l">
            <tr>
                <th>Name :</th>
                <th>Marks Gained :</th>
            </tr>
            <?php
            include("quiz_conn.php");
            $sql2 = "SELECT * FROM quiz_3";
            $result2 = $connect->query($sql2);
            while ($row2 = $result2->fetch_assoc()) {
            ?>
                <tr>
                    <td><?php echo $row2["parti"]; ?></td>
                    <td><?php echo $row2["total"]; ?></td>
                </tr>
            <?php
            }
            ?>
        </table>
        <form action="quiz1.php" method="POST">
            <input id="ff" type="submit" value="Try another time">
        </form>
    </center>
</body>
</html>