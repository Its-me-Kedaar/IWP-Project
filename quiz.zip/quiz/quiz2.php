<?php
$v1 = $_POST["q1"];
$v2 = $_POST["q2"];
$v3 = $_POST["q3"];
$v4 = $_POST["q4"];
$v5 = $_POST["q5"];
$v8 = $_POST["nam"];
$m = 0;
if ($v1 == "a") {
    $m += 1;
}
if ($v2 == "b") {
    $m += 1;
}
if ($v3 == "b") {
    $m += 1;
}
if ($v4 == "b") {
    $m += 1;
}
if ($v5 == "d") {
    $m += 1;
}
echo "You have scored : ".$m." out of 5"."<br>";
include("quiz_conn.php");
$sql1 = "INSERT INTO quiz_3(parti, q1, q2, q3, q4, q5, total) VALUES ('$v8', '$v1', '$v2', '$v3', '$v4', '$v5', $m)";
$result = $connect->query($sql1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quick review</title>
    <style>
        p {
            display: none;
        }
        #aa {
            margin-top: 10px;
        }
        body {
            background-color:#808080;
        }
    </style>
</head>
<body>
    <center>
    <button>Check answers</button>
    <p>Your answer: <?php echo $v1; ?> Correct answer: a</p>
    <p>Your answer: <?php echo $v2; ?> Correct answer: a</p>
    <p>Your answer: <?php echo $v3; ?> Correct answer: c</p>
    <p>Your answer: <?php echo $v4; ?> Correct answer: c</p>
    <p>Your answer: <?php echo $v5; ?> Correct answer: b</p>
    <form action="quiz3.php" method="POST">
        <input id="aa" type="submit" value="score board">
    </form>
    </center>
    <script>
        var v6 = document.getElementsByTagName("button");
        var v7 = document.getElementsByTagName("p");
        v6[0].addEventListener("click", function() {
            for (var i = 0; i < 5 ; i++) {
                v7[i].style.display = "block";
            }
        });
        v6[0].addEventListener("mouseout", function() {
            for (var i = 0; i < 5 ; i++) {
                v7[i].style.display = "none";
            }
        })
    </script>
</body>
</html>