<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz</title>
    <style>
        h3 {
            color: violet;
        }
        h1 {
            text-align: center;
            color: blue;
        }
        body {
            background-color: #808080;
        }
        #nam {
            margin-top: 20px;
        }
		.div {
		border: 5px outset red;
  background-color: lightblue;
  text-align: center;	
		}		
    </style>
</head>
<body>
    <h1>Quiz Portal</h1>
	<div style="border:solid">
    <?php
    include("quiz_conn.php");
    $sql = "SELECT * FROM quiz_1";
    $result = $connect->query($sql);
    $n = 1;
    while ($row = $result->fetch_assoc()) {
    ?>
        <form action="quiz2.php" method="POST">
            <h3><?php echo $n . ") " . $row["question"]; ?></h3>
            <input type="radio" name="q<?php echo $n; ?>" value="a"><?php echo $row["op1"] . "<br>"; ?>
            <input type="radio" name="q<?php echo $n; ?>" value="b"><?php echo $row["op2"] . "<br>"; ?>
            <input type="radio" name="q<?php echo $n; ?>" value="c"><?php echo $row["op3"] . "<br>"; ?>
            <input type="radio" name="q<?php echo $n; ?>" value="d"><?php echo $row["op4"] . "<br>"; ?>

        <?php
        $n += 1;
    }
        ?>
        Enter your name: <input id="nam" type="text" name="nam"> <br>
        <center>
            <input class="gih" type="submit">
        </center>
        </form>
		</div>
</body>
</html>