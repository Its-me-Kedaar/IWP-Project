<?php

$connect = new mysqli('localhost', 'root', '', 'iwp');

if (!$connect) {
    die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}


?>